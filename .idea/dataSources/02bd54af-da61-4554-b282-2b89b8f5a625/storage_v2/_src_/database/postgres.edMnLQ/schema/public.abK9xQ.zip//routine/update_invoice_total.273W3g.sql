create function update_invoice_total() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE invoices
    SET total_amount = (SELECT COALESCE(SUM(item_amount), 0) FROM invoice_items WHERE invoice_id = NEW.invoice_id)
    WHERE invoice_id = NEW.invoice_id;
    RETURN NEW;
END;
$$;

alter function update_invoice_total() owner to postgres;

